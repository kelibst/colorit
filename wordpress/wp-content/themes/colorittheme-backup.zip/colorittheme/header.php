<?php
/**
 * The header for our theme
 */
?><!Doctype html>
<html>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<meta name="description" content="This is the official colorit site, we provide a range of services including, website designs, graphic designs and more. We aim to improve the gap that exist in the IT infrastructure Africa.">
	<?php wp_head(); ?>
</head>
<body class="grey lighten-5">
	<div id="up"></div>
	<div class="navbar-fixed  white-text  z-depth-0">
		<nav class="transparent1">
			<div class="nav-wrapper container">
				<a class="brand-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				<?php if ( has_nav_menu( 'menu-1' ) ) : ?>
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'menu-1',
							'menu_class'     => 'right',
							'items_wrap'     => '<ul id="%1$s" class="%2$s" tabindex="0">%3$s</ul>',
						)
					);
					?>
				</div>
			</nav><!-- #site-navigation -->			


		</div>	

	<?php endif;?>
<?php if (is_front_page()):?>
	
<!-- slider insert -->

  <div class="slider">
    <ul class="slides">
      <li>
        <img src="<?php bloginfo('template_url'); ?>/img/background3.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3 class="big-tagline">This is our big Tagline!</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="<?php bloginfo('template_url'); ?>/img/background1.jpg"> <!-- random image -->
        <div class="caption left-align">
          <h3 class="big-tagline">Left Aligned Caption</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="<?php bloginfo('template_url'); ?>/img/background2.jpg""> <!-- random image -->
        <div class="caption right-align">
          <h3 class="big-tagline">Right Aligned Caption</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="<?php bloginfo('template_url'); ?>/img/background5.jpg""> <!-- random image -->
        <div class="caption center-align">
          <h3 class="big-tagline">This is our big Tagline!</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
    </ul>
  </div>


<?php endif; ?>

