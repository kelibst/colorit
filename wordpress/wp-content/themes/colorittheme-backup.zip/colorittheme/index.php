<?php
/**
 * The main template file
 */

get_header();

get_footer();