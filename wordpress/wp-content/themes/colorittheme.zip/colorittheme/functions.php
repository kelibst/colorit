<?php
/**
 * Twenty Nineteen functions and definitions
 */
// This theme uses wp_nav_menu() in two locations.
		register_nav_menus(
			array(
				'menu-1' => __( 'Primary', 'colorittheme' ),
				'footer' => __( 'Footer Menu', 'colorittheme' ),
				'social' => __( 'Social Links Menu', 'colorittheme' ),
			)
		);
		//enqueueing scripts
		function coloritscripts(){
			wp_enqueue_script('jquery-js', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.0/jquery.js', array('jquery'), '1.0', false  );

			wp_enqueue_script('materialize-js', get_template_directory_uri() . '/js/materialize.js', array('jquery'), '2.1.0', true  );
			

			// main themes style
			wp_enqueue_style( 'colorit-style', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
		//enqueue materialize css
			wp_enqueue_style( 'materialize-css', get_template_directory_uri() . '/css/materialize.css', array(), wp_get_theme()->get( 'Version' ) );

			wp_enqueue_style('materialize-icons', 'https://fonts.googleapis.com/icon?family=Material+Icons', array(),  wp_get_theme()->get( 'Version' ) );
		//enqueue needed fonts
			wp_enqueue_style( 'font-awesome', 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(), wp_get_theme()->get( 'Version' ) );

			wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css?family=Carter+One|Charm|Charmonman|Dancing+Script|Lobster|Lobster+Two|Mountains+of+Christmas|Pacifico|Satisfy', array(), wp_get_theme()->get( 'Version' ) );


			//enqueue scripts
			wp_enqueue_script('colorit-js', get_template_directory_uri() . '/js/init.js', array(), '1.0', false  );
			
		}
		add_action('wp_enqueue_scripts', 'coloritscripts');