<?php
/**
 * The header for our theme
 */
?><!Doctype html>
<html>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<meta name="description" content="This is the official colorit site, we provide a range of services including, website designs, graphic designs and more. We aim to improve the gap that exist in the IT infrastructure Africa.">
	<?php wp_head(); ?>
</head>
<body class="grey lighten-5">
	<div id="up"></div>
	<div class="white-text">
		<nav class="teal darken-2">
			<div class="nav-wrapper container">
				<a class="brand-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				<a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
				<?php if ( has_nav_menu( 'menu-1' ) ) : ?>
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'menu-1',
							'menu_class'     => 'right',
							'items_wrap'     => '<ul id="%1$s" class="%2$s" tabindex="0">%3$s</ul>',
						)
					);
					?>
		</ul>

		<ul id="nav-mobile" class="sidenav">

					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'menu-1',
							'menu_class'     => '',
							'items_wrap'     => '<ul id="%1$s" class="%2$s" tabindex="0">%3$s</ul>',
						)
					);
					?>
			</ul>
				</div>
			</nav><!-- #site-navigation -->			


		</div>	

	<?php endif;?>
<?php if (is_front_page()):?>
	
<!-- slider insert -->

  <div class="slider">
    <ul class="slides">
      <li>
        <img src="<?php bloginfo('template_url'); ?>/img/background3.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3 class="big-tagline">This is our big Tagline!</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="<?php bloginfo('template_url'); ?>/img/background1.jpg"> <!-- random image -->
        <div class="caption left-align">
          <h3 class="big-tagline">Left Aligned Caption</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="<?php bloginfo('template_url'); ?>/img/background2.jpg""> <!-- random image -->
        <div class="caption right-align">
          <h3 class="big-tagline">Right Aligned Caption</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="<?php bloginfo('template_url'); ?>/img/background5.jpg""> <!-- random image -->
        <div class="caption center-align">
          <h3 class="big-tagline">This is our big Tagline!</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
    </ul>
  </div>
<?php else:?>


<!-- parallax side -->

<div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container lighten-3 register">
        
        <br><br>
        <h1 class="header center teal-text text-lighten-2">GET ONLINE</h1>
        <div class="row center">
          <h5 class="header col s12 ">Let's get you online the professional way</h5>
        </div>
        
        <br><br>

      </div>
    </div>
    <div class="parallax"><img src="<?php bloginfo('template_url'); ?>/img/backgroundpara1.jpg" alt="Unsplashed background img 1"></div>


<?php endif; ?>

