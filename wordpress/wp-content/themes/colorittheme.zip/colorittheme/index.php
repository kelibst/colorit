<?php
/**
 * The main template file
 */
;?>
<?php get_header();?>

<?php get_footer();?>